(()=>{const b="src/mini/index.html",c="miniPos",x={right:16,bottom:96},f=`
:host{all:initial}
.card{position:fixed;z-index:2147483647;box-sizing:border-box;
  width:360px;height:190px;max-width:calc(100vw - 32px);border-radius:18px;overflow:hidden;background:#0b0b0d;
  box-shadow:0 24px 60px -18px rgba(0,0,0,.65),0 0 0 1px rgba(236,235,231,.12);
  opacity:0;transform:translateY(16px) scale(.96);pointer-events:none;
  transition:opacity .22s ease,transform .42s cubic-bezier(.2,.8,.2,1)}
.card[data-open]{opacity:1;transform:none;pointer-events:auto}
.card[data-dragging]{transition:none}
.card[data-dragging] iframe{pointer-events:none}
iframe{display:block;width:100%;height:100%;border:0;color-scheme:dark}
.grip{position:absolute;top:0;left:0;right:40px;height:16px;cursor:grab;touch-action:none;display:grid;place-items:center}
.grip::after{content:"";width:36px;height:4px;border-radius:99px;background:rgba(236,235,231,.22);opacity:0;transition:opacity .15s}
.card:hover .grip::after,.card[data-dragging] .grip::after{opacity:1}
.card[data-dragging] .grip{cursor:grabbing}
.x{position:absolute;top:10px;right:10px;display:grid;place-items:center;width:22px;height:22px;margin:0;padding:0;
  border:1px solid rgba(236,235,231,.18);border-radius:999px;background:rgba(18,18,21,.8);color:#ecebe7;cursor:pointer;
  opacity:0;transition:opacity .15s}
.card:hover .x,.x:focus-visible{opacity:1}
@media (prefers-reduced-motion:reduce){.card{transition:none}}
`,v='<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>';let i=null,a=null,n=null,s=null,r=x;function p(t){try{chrome.runtime.sendMessage(t).catch(()=>{})}catch{}}function d(){if(!i)return;const t=Math.min(360,innerWidth-32),e=Math.max(16,Math.min(r.right,innerWidth-t-16)),o=Math.max(16,Math.min(r.bottom,innerHeight-190-16));i.style.right=e+"px",i.style.bottom=o+"px"}function y(t,e){e.addEventListener("pointerdown",o=>{if(o.button!==0)return;o.preventDefault(),e.setPointerCapture(o.pointerId),t.setAttribute("data-dragging","");const l={x:o.clientX,y:o.clientY,...r},h=g=>{r={right:l.right-(g.clientX-l.x),bottom:l.bottom-(g.clientY-l.y)},d()},m=()=>{t.removeAttribute("data-dragging"),e.removeEventListener("pointermove",h),r={right:parseFloat(t.style.right),bottom:parseFloat(t.style.bottom)},chrome.storage.local.set({[c]:r}).catch(()=>{})};e.addEventListener("pointermove",h),e.addEventListener("pointerup",m,{once:!0}),e.addEventListener("pointercancel",m,{once:!0})})}function w(){if(a&&i)return a.isConnected||document.documentElement.appendChild(a),i;a=document.createElement("disc-deck-mini");const t=a.attachShadow({mode:"closed"});t.innerHTML=`<style>${f}</style><div class="card" role="region" aria-label="Now playing"><div class="grip" title="Drag to move"></div><button class="x" aria-label="Close">${v}</button></div>`,document.documentElement.appendChild(a);const e=t.querySelector(".card");return e.querySelector(".x").addEventListener("click",()=>{u(),s!=null&&p({type:"mini:dismiss",tabId:s})}),y(e,e.querySelector(".grip")),addEventListener("resize",d),i=e,d(),e}function E(t){var o;const e=w();if(s=t,n){(o=n.contentWindow)==null||o.postMessage({discDeck:"show",tabId:t},new URL(n.src).origin),e.setAttribute("data-open","");return}n=document.createElement("iframe"),n.title="Disc Deck mini player",n.src=chrome.runtime.getURL(b)+"?tab="+t,n.addEventListener("load",()=>requestAnimationFrame(()=>e.setAttribute("data-open","")),{once:!0}),e.prepend(n)}function u(){if(!i)return;i.removeAttribute("data-open");const t=n;setTimeout(()=>{t&&n===t&&!(i!=null&&i.hasAttribute("data-open"))&&(t.remove(),n=null)},450)}chrome.runtime.onMessage.addListener(t=>{t.type==="mini:state"&&t.pop?E(t.media.tabId):t.type==="mini:gone"&&t.tabId===s&&(u(),s=null)}),chrome.storage.local.get(c).then(t=>{t[c]&&(r=t[c]),d()}).catch(()=>{}),document.visibilityState==="visible"&&p({type:"mini:ready"})})();
