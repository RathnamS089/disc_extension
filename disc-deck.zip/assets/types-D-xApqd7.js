const o="autoPop";export{o as A};
